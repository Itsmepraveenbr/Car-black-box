/* 
 * File:   main.h
 * Author: KUMAR
 *
 * Created on 18 October, 2024, 12:41 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#include "adc.h"
#include "clcd.h"
#include "digital_keypad.h"
#include "i2c.h"
#include "ds1307.h"
#include "timer.h"
#include "external_eeprom.h"
#include "uart.h"

char time[9];  // "HH:MM:SS" array to hold the time information


void default_screen(unsigned char key);
void password_screen(unsigned char key);
void menu_screen(unsigned char key);


void store_events(char* time, char** event, char* speed);
void read_events(char * logs,int addr);


void view_log(unsigned char key);
void download_log();
void clear_log();
void set_time(unsigned char key);
void change_password(unsigned char key);
void read_password(unsigned char key, char *buffer);

#endif	/* MAIN_H */

