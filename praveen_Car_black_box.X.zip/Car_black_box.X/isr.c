#include <xc.h>
#include "main.h"

int seconds = 0, timeout = 0;
extern int timeout_flag;
unsigned int count = 0;

void __interrupt() isr(void)
{
    if(timeout_flag == 1)
    {
        timeout = 120;
        timeout_flag = 0;
    }
    
    if (TMR0IF == 1)
    {
        TMR0 = TMR0 + 6 + 2;
        
        if (count++ == 20000)
        {                                 
            seconds++;           
            timeout--;
            count = 0;             
        }
        
        TMR0IF = 0;
    } 
   
   
}