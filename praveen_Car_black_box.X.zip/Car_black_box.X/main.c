/*
 * File:   main.c
 * Author: PRAVEEN B R
 *
 * Created on 18 October, 2024, 12:40 PM
 */


#include <xc.h>
#include "main.h"

#pragma config WDTE = OFF

 unsigned char operation_flag = 1, clear_flag = 1 , logout_flag = 1; 
 extern int seconds , p_flag, pos;
 
void init_config(void)
{
    init_clcd();
    init_digital_keypad();
    init_adc();
    init_i2c(100000);
    init_ds1307();
    init_timer0();
    init_uart(9600);
    
}

void main(void) {
    init_config();
    
//    write_ext_eeprom(120, '1');
//    write_ext_eeprom(121, '1');
//    write_ext_eeprom(122, '1');
//    write_ext_eeprom(123, '1');
    
    unsigned char key;
    while (1) 
    {
        
        if(operation_flag != 3)
        {
            key = read_digital_keypad(STATE);     
        
            if(logout_flag) //if not logout flag not set
            {
                //if no keys are pressed for 5 seconds then logout and display the default screen
                if((key == ALL_RELEASED) && (seconds == 5) )
                {
                    seconds = 0;
                    operation_flag = 1;  //display the default screen flag is set
                    p_flag = 0;   //if it came out of password next time the sw4 press has to work as expected
                    clear_flag = 1;  //to clear the screen for password to enter password
                    pos = 5;   //reset the position of password
                }
                else if(!(key == ALL_RELEASED))  //if any key is pressed then reset the timer to 0 seconds
                {
                    seconds = 0;
                }
            }
        
            if(key == SW1 || key == SW2 || key == SW3 )
            {
                operation_flag = 1;
                clear_flag = 1;

            }
            else if(key == SW4)
            {
                operation_flag = 2;
            
                //clear the screen only once when the sw4 is pressed
                if(clear_flag)
                {
                    clcd_print("                ",LINE1(0));
                    clcd_print("                ",LINE2(0));
                    clear_flag = 0;
                }
            }
        
            if(operation_flag == 1)
            {
                default_screen(key);
                p_flag = 0;
            }
            else if(operation_flag == 2)
            {
                //login screen
                password_screen(key);
            
            }
            else if(operation_flag == 3)
            {
                //menu screen
                menu_screen(key);
                p_flag = 0;
            }
        }
        else
        {
            key = read_digital_keypad(LEVEL_DETECTION);
            
            if(logout_flag) //if not logout flag not set
            {
                //if no keys are pressed for 5 seconds then logout and display the default screen
                if((key == ALL_RELEASED) && (seconds == 5) )
                {
                    seconds = 0;
                    operation_flag = 1;  //display the default screen flag is set
                    p_flag = 0;   //if it came out of password next time the sw4 press has to work as expected
                    clear_flag = 1;  //to clear the screen for password to enter password
                    pos = 5;   //reset the position of password
                }
                else if(!(key == ALL_RELEASED))  //if any key is pressed then reset the timer to 0 seconds
                {
                    seconds = 0;
                }
            }
            
            menu_screen(key);
                    
        }
        
     }

}
