/*
 * File:   menu_screen.c
 * Author: PRAVEEN B R
 *
 * Created on 20 October, 2024, 6:17 PM
 */


#include <xc.h>
#include "main.h"

unsigned char * menu_options[] = {" view log       ", " download log   ", " clear log      ", " set time       " , " change passwd   "};
unsigned char position = 0,SW4_flag = 0, SW5_flag = 0, inside_menu = 0, b = 0, blink_flag = 1;
unsigned int long_press_SW4 = 0, long_press_SW5 = 0, match_count = 0,temp1C = 0, p = 0, first_entry = 1, time_flag = 1, k = 0, new_sec, new_hr, new_min, m = 6;
static unsigned int  wait = 0;
char  address = 0,event_num = 0 ; 
unsigned char new_time[3] = {0};
 
extern unsigned char operation_flag , clear_flag , event_count, reset_flag, addr, logout_flag;
extern char time[9];

//function to display menu screen
void menu_screen(unsigned char key)
{ 
    if(inside_menu == 0)
    {
        logout_flag = 1;  // to set the logout flag which logouts if 5 sconds of inactivity
        if(key == SW4) 
        {    
            if(long_press_SW4++ == 10)
            {
                SW4_flag = 1;  
                long_press_SW4 = 0;          
            }
            else  if(long_press_SW4 > 10)
            {
                long_press_SW4 = 15;
                SW4_flag = 1; 
            }      
        }
        else if((long_press_SW4 > 0)  && (long_press_SW4 < 10))
        {

            if(position == 0)
            {
                position = 1;
            }
            position--;
              
            long_press_SW4 = 0;
        }
        
        if(key == SW5)
        {        
            long_press_SW5++;
            if(long_press_SW5 == 10)
            {
                SW5_flag = 1;  
                long_press_SW5 = 0;
            }
            else  if(long_press_SW5 > 10)
            {
                long_press_SW5 = 15;
                SW5_flag = 1;                  
            }
        }
        else if((long_press_SW5 > 0)  && (long_press_SW5 < 10))
        {
            if(position == 4)
            {
                position = 3;
            }
            position++;
                
            long_press_SW5 = 0;
        }
    
        if(position != 4)
        {
            clcd_putch('*',LINE1(0));
            clcd_print(menu_options[position],LINE1(1));
            clcd_print(menu_options[position+1],LINE2(0));
        }
        else
        {
            //clcd_putch(' ',LINE1(0));
            clcd_print(menu_options[position-1],LINE1(0));
            clcd_print(menu_options[position],LINE2(1));
            clcd_putch('*',LINE2(0));
        }
        if(SW4_flag)
        {
            clcd_print("                ",LINE1(0));
            clcd_print("                ",LINE2(0));
            inside_menu = 1;
            SW4_flag = 0;
            long_press_SW4 = 0;
            logout_flag = 0;
        }
        if(SW5_flag)
        {
            clcd_print("                ",LINE1(0));
            clcd_print("                ",LINE2(0));
            operation_flag = 1;
            clear_flag = 1;
            SW5_flag = 0;
            long_press_SW5 = 0;
            logout_flag = 1;
        }
    }
    else
    {
        switch(position)
        {
            case 0 :
                view_log(key);
                break;
            case 1 :
                download_log();
                break;
            case 2 :
                clear_log();
                break;
            case 3:
                set_time(key);
                break;
            case 4 :
                change_password(key);
                break;          
        }       
    }
}

//function to view the logs
void view_log(unsigned char key)
{
   char logs[14];  //buffer array to store the data being read from ext eeprom
    
   if(reset_flag == 0)   //check if reset flag is set or not
   { 
    //if no events are recorded then print no logs available
        if(event_count == 0) 
        {
            clcd_print("NO logs Avalable",LINE1(0));
            clcd_print("                ",LINE2(0));
            if(wait++ == 5)   //delay 
            {
                inside_menu = 0;
                wait = 0;
            }
        } 
        else
        {
            //if events are recorded then display the recorded events      
            clcd_print("# TIME      E SP",LINE1(0));
                       
            if(key == SW4)  
            {
                //to check if sw4 is pressed as short press or long press
                long_press_SW4++;
                if(long_press_SW4 > 10)   //if long pressed go inside the selected menu 
                {
                    inside_menu = 0;
                    long_press_SW4 = 0;
                    event_num = 0;
                }
            }
            else if((long_press_SW4) > 0 && (long_press_SW5 < 10))
            {
                //if short press increment the count
                if(event_num < (event_count - 1))
                {           
                    event_num++;
                    address = address+12; //increment the address by 12 so that it points to the next event information
                }   
                long_press_SW4 = 0;
            }
    
            if(key == SW5)
            {        //to check if sw4 is pressed as short press or long press
                long_press_SW5++;
                if(long_press_SW5 > 10)  //if long pressed go to default screen
                {
                    //reset the flag variables
                    operation_flag = 1;
                    clear_flag = 1;
                    inside_menu = 0;
                    long_press_SW5 = 0;
                    event_num = 0;
                }
            }
            else if((long_press_SW5 > 0) && (long_press_SW5 < 10))
            {
                //if short pressed decrease the count
                if(event_num > 0 )
                {          //decrement the address by 12 so that it points to the previous event information
                    address = address-12;
                    event_num--;
                }
                long_press_SW5 = 0;
            }
               
            clcd_putch(event_num + '0',LINE2(0));
            clcd_putch(' ',LINE2(1));
            
            read_events(logs,address);  //call the function to read the event
            
            clcd_print(logs,LINE2(2));
        }
    }
    else
    {
        clcd_print("NO logs Avalable",LINE1(0));
        clcd_print("                ",LINE2(0));
        if(wait++ == 5)  //delay
        {
            inside_menu = 0;
            wait = 0;
        }
    }  
}

//function to read 12 bytes of info from the ext eeprom
void read_events(char * logs,int addr)
{
        for(int i=0;i<14;i++)
        {           
            if(i == 8) 
            {
                logs[i] = ' ';
            }
            else if(i == 11)
            {
                logs[i] = ' ';
            }
            else
            {                
                logs[i] = read_ext_eeprom(addr);
                addr++;
            }              
        }       
}

//function to download logs
void download_log()
{
    //if no events are recorded print no events available
    if(event_count == 0)
    {
        clcd_print("   No Logs to   ",LINE1(0));
        clcd_print("   Download     ",LINE2(0));
        __delay_ms(2000);   //to provide delay
        //to clear the display
        clcd_print("                ",LINE1(0));
         clcd_print("                ",LINE1(0));
         inside_menu = 0;   //reset the menu flag 
    }
    else   //if events are recorded then print them on teraterm
    {
        char download_logs[14];  //temporary array to store the event information
        static char ad = 0;         //temporary variable to hold the address 
        puts("LOGS: \n");  
        putchar('\r');   //to print the info in same order
        puts("# Time  E  SP");
        putchar('\n');
        putchar('\r');
        //loop till the number of events revcorded
        for(int i = 0; i < event_count ; i++)
        {
            //read events one by one and store them in the temporaryb array
            read_events(download_logs,ad);   
            puts(download_logs);  //print the read events 
            putchar('\n');
            putchar('\r');
            ad = ad+12;
        }
        clcd_print("Logs Downloaded ",LINE1(0));
        clcd_print(" successfully   ",LINE2(0));
        __delay_ms(2000); 
       inside_menu = 0;  //to reset the menu flag
       ad = 0;  // to reset the adddress to 0 so that next time it prints from 0th address
    }
 
}

//function to clear the content of the log
void clear_log()
{
    reset_flag = 1;    //make the reset flag 1
    clcd_print("  Logs cleared  ",LINE1(0));
    clcd_print("  Successfully  ",LINE2(0));
    if(wait++ == 5)  //delay
    {
        //reset the flag variables
        inside_menu = 0;
        event_count = 0;
        event_num = 0;
        addr = 0x00;  //reset the address to 0
        wait = 0;    //reset the delay
        
    }
}

//function to change time
void set_time(unsigned char key)
{
    clcd_print("Time (HH:MM:SS) ",LINE1(0));
    
    //to get the value for hour min and sec from the time array 
    //this is donr only once so time_flag is used
    if(time_flag)
    {          
        new_hr = ((time[0] - '0')*10) + (time[1] - '0') ;
        new_min = ((time[3] - '0')*10) + (time[4] - '0') ;
        new_sec = ((time[6] - '0')*10) + (time[7] - '0') ;
    
        time_flag = 0;  //reset the time _ flag so that this operation is performed only once
    }
       
    if(key == SW4)
    {
        long_press_SW4++;
        if(long_press_SW4 > 10)
        {
            //conversion to BCD
            new_time[0] = (new_time[0] | (new_hr / 10) );
            new_time[0] = (new_time[0] <<4 ) | (new_hr % 10) ;
                
            new_time[1] = (new_time[1] |(new_min / 10)) ;
            new_time[1] = (new_time[1] <<4 ) |(new_min % 10);
                
            new_time[2] = (new_time[2] |(new_sec / 10));
            new_time[2] = (new_time[2] <<4 ) | (new_sec % 10);
                
            //call the function to change the time 
            change_time(new_time);
            //reset the flags    
            time_flag = 1;
            long_press_SW4 = 0;
            inside_menu = 0;
        }
    }
    //for short press change the position
    else if((long_press_SW4>0) && (long_press_SW4<10))
    {
        if(k == 0)
        {
            if(++new_hr > 23)
            {
                new_hr = 00;
            }
        }
        else if(k == 1)
        {
            if(++new_min > 59)
            {
                new_min = 00;
            }           
        }
        else if(k == 2)
        {
            if(++new_sec > 59)
            {
                new_sec = 0;
            }
        }
        
        long_press_SW4 = 0;
    }
    if(key == SW5)
    {
        long_press_SW5++;
        if(long_press_SW5 >10)
        {
            inside_menu = 0;
            long_press_SW5 = 0;
            time_flag = 1;
        }
    }
    else if((long_press_SW5 > 0) && (long_press_SW5 < 10))
    {
        if(++k > 2)
        {
            k = 0;
        } 
        if(k == 0)
        {
            m = 6;  // m flag variable is used to blink the position of content to be changed (HH MM SS)
        }
        else if(k == 1)
        {
            m = 9;
        }
        else if(k == 2)
        {
            m = 12;
        }
        long_press_SW5 = 0;
    }
    //logic to blink the position of content being edited
    if(++b == 3)
    {
        blink_flag = !blink_flag;
        b = 0;
    }
    if(blink_flag)
    {
        clcd_print("      ",LINE2(0));
        clcd_putch((new_hr / 10) + '0',LINE2(6));
        clcd_putch((new_hr % 10) + '0',LINE2(7));
        clcd_putch(':',LINE2(8));
        clcd_putch((new_min / 10) + '0',LINE2(9));
        clcd_putch((new_min % 10) + '0',LINE2(10));
        clcd_putch(':',LINE2(11));
        clcd_putch((new_sec / 10) + '0',LINE2(12));
        clcd_putch((new_sec % 10) + '0',LINE2(13));
    
        clcd_print("   ",LINE2(14));
    }
    else
    {
        clcd_putch(' ', LINE2(m));    
        clcd_putch(' ', LINE2(m+ 1));
    }
}

//function to change the password
void change_password(unsigned char key)
{
    //temporary arrays to hold password and re entered password
    static char temp[4];  
    static char temp2[4];
    
    //since long press of sw4 selects this menu we have to make sure that it does not gets presed inside tis function also during this time
    if(first_entry)
    {
        if(key == ALL_RELEASED)
        {
            if(wait++ == 35)  //to overcome the sw4 being pressed due to debouncing effect
            {
                first_entry = 0;
                long_press_SW4 = 0;
                long_press_SW5 = 0;
                wait = 0;
            }
        }
    }
    else
    {
        if((temp1C == 0) || (temp1C == 4))
        {
            clcd_print("                  ",LINE2(0));
            p = 0;        //to reset the position of next array to 0   // p flag is used for the position 
        }
   
        if(temp1C < 4)  // to read the password for 1st time
        {
            clcd_print("enter the password", LINE1(0));      
            read_password(key,temp);     
        }
        else if(temp1C < 8)  //to confirm the entered password
        {    
            clcd_print("RE enter password",LINE1(0));
            read_password(key,temp2);
        }
        //if 8 characters are read then compare the both 
        if(temp1C == 8 )
        {
            if(match_count == 0)
            {
                for(int i = 0 ;i < 4; i++)
                {
                    if(temp[i] == temp2[i])
                    {
                        match_count++;
                    }
                }
            }
                //if the password match then change the password
            if(match_count == 4)
            {   
                clcd_print("Password changed", LINE1(0));
                clcd_print(" Successfully ",LINE2(0));
                if(wait++ == 5)
                {
                    write_ext_eeprom(120,temp[0]);
                    write_ext_eeprom(121,temp[1]);
                    write_ext_eeprom(122,temp[2]);
                    write_ext_eeprom(123,temp[3]); 
                    inside_menu = 0;
                    wait = 0;
                    temp1C = 0;
                    match_count = 0;
                    p = 0;
                    first_entry = 1;
                }
            }
            else
            {
                clcd_print("password mismatch",LINE1(0));
                clcd_print("   TRY Again    ",LINE2(0));
                if(wait++ == 5)
                {
                    inside_menu = 0;
                    wait = 0;
                    match_count = 0;
                    p = 0;
                    temp1C = 0;
                    first_entry = 1;
                }
            }
        }
    }
}

//function to read the password 
void read_password(unsigned char key, char *buffer)
{ 
    if(key == SW4)
    {
        long_press_SW4++;
        if(long_press_SW4 >15)
        {
            long_press_SW4 = 0 ;
        }
    }
    else if(long_press_SW4 > 0 && (long_press_SW4 < 15))
    {
        clcd_print("*",LINE2(p));    
        buffer[p++] = '0';
        temp1C++;
        long_press_SW4 = 0 ;
    }
    
    if(key == SW5)
    {
        long_press_SW5++;
        if(long_press_SW5 >15)
        {
            long_press_SW5 = 0 ;
        }
    }
    else if(long_press_SW5 > 0 && (long_press_SW5 < 15))
    {
        clcd_print("*",LINE2(p));
        buffer[p++] = '1';
        temp1C++;
        long_press_SW5 = 0 ;
    }
      
}