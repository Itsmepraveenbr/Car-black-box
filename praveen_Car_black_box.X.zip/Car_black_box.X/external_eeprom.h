/* 
 * File:   ds1307.h
 */

#ifndef EXTERNAL_EEPROM_H
#define	EXTERNAL_EEPROM_H

#define S_WRITE                 0xA0
#define S_READ                  0xA1

#define EE                     0X00;

unsigned char read_ext_eeprom(unsigned char addr);
void write_ext_eeprom(unsigned char addr, unsigned char data);

#endif	/* DS1307_H */

