/*
 * File:   timer.c
 * Author: PRAVEEN B R
 *
 * Created on 2 October, 2024, 5:28 PM
 */


#include <xc.h>
#include "timer.h"
#pragma config WDTE = OFF

void init_timer0()
{
    
    /* Setting the internal clock source */
    T0CS = 0;
    
    /* Assinging the prescaler to Watchdog Timer */
    PSA = 1;

    TMR0 = 6;
    
    /* The timer interrupt is enabled */
    TMR0IE = 1;
    
    TMR0IF = 0;
    
    GIE = 1;
    PEIE = 1;
}
