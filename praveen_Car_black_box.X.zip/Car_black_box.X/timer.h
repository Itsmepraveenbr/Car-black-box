/* 
 * File:   timer.h
 * Author: KUMAR
 *
 * Created on 2 October, 2024, 5:46 PM
 */

#ifndef TIMER_H
#define	TIMER_H


void init_timer0();


#endif	/* TIMER_H */

