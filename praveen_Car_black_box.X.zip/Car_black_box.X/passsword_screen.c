/*
 * File:   passsword_screen.c
 * Author: PRAVEEN B R
 *
 * Created on 18 October, 2024, 5:12 PM
 */


#include <xc.h>
#include "main.h"

char pass[4];
char usr_pass[4];
int pos = 5;
unsigned char attempt = 3;
int  blink = 0 , timeout_flag = 0, p_flag = 0; 
extern char operation_flag;
extern int timeout;

void password_screen(unsigned char key)
{
    pass[0] = read_ext_eeprom(120);
    pass[1] = read_ext_eeprom(121);
    pass[2] = read_ext_eeprom(122);
    pass[3] = read_ext_eeprom(123);
    
        if(attempt>0)
        {
            timeout_flag = 0;
            
            clcd_print(" Enter Password ", LINE1(0));
            
            if(blink++ >= 5)
            {
                clcd_putch(0xFF,LINE2(pos));
                if(blink == 10)
                {
                    clcd_print("_",LINE2(pos));
                    blink = 0;
                }
            }
        
            if((key == SW4) && (p_flag++ > 0))
            {
                usr_pass[pos-5] = '0';
                clcd_print("*",LINE2(pos));
                pos++;
                
            }
            if(key == SW5)
            {
                usr_pass[pos-5] = '1';
                clcd_print("*",LINE2(pos));
                pos++;
            }
            int count = 0;
            
            if(pos == 9)
            {
                //compare the password
                for(int i=0;i<4;i++)
                {
                    if(pass[i] == usr_pass[i])
                    {
                        count ++;
                    }
                }
                //password match
                if(count == 4)
                {
                    clcd_print("    SUCCESS!!   ",LINE1(0));
                    clcd_print("                ",LINE2(0));
                    operation_flag = 3;
                    pos = 5;
                    attempt = 3;
                }
                //password mismatch
                else
                {               
                    attempt--;
                    
                    clcd_print("wrong password", LINE1(1));
                    clcd_putch(attempt + '0', LINE2(0));
                    clcd_print(" Attempts left", LINE2(1));
                    
                    for(int j=0; j<26000; j++);    
                     pos = 5;  
                     clcd_print("                ",LINE2(0));
                    
                    if(attempt == 0)
                    {
                        timeout_flag = 1;
                    }
                     
                }  
            }
                      
        }
        else
        {
            
            clcd_print("you are blocked", LINE1(0));
            clcd_print("wait ", LINE2(0));
            
            clcd_putch((timeout / 100) + '0',LINE2(5));
            clcd_putch(((timeout / 10) % 10) + '0',LINE2(6));
            clcd_putch((timeout % 10) + '0',LINE2(7));
            
            clcd_print(" seconds",LINE2(8));
            
            if(timeout == 0)
            {
                clcd_print("                ",LINE1(0));
                clcd_print("                ",LINE2(0));
                
                attempt = 3;
            }
            
        }
  
}