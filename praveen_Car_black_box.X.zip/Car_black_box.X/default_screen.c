/*
 * File:   default_screen.c
 * Author: PRAVEEN B R
 *
 * Created on 18 October, 2024, 4:34 PM
 */


#include <xc.h>
#include "main.h"

unsigned char* events[] = {"ON" ,"GN" ,"G1" ,"G2" ,"G3" ,"G4" ,"GR" ,"C "};
unsigned char clock_reg[3] , speed[3] = {0};
unsigned char i = 0,addr = 0, event_count = 0 , reset_flag = 0;
unsigned short adc_val;


void default_screen(unsigned char key)
{
    clcd_print("  TIME     E  SP",LINE1(0));
        
        //get time from rtc
        get_time(clock_reg);
        
        //display time
        display_time(clock_reg);

        //display speed
        adc_val = read_adc() / 10.23;
        speed[0] = (adc_val / 10) + '0';
        speed[1] = (adc_val % 10) + '0';
              
        //gear shifting events
        if(key == SW1)
        {
            i = 7;
            //store event
            store_events(time,events[i],speed);
            event_count++;   //increment the event count
            reset_flag = 0;  // reset the reset flag to 0 if reset option was selected before
        }
        else if(key == SW2)
        {
            if(i<6)
            {
                i++;           
                //store event
                store_events(time,events[i],speed);
                event_count++;  //increment the event count
                reset_flag = 0;// reset the reset flag to 0 if reset option was selected before
            }
        }
        else if(key == SW3)
        {
            if(i > 1)
            {
                i--;            
                //store events
                store_events(time,events[i],speed);
                event_count++;  //increment the event count
                reset_flag = 0;  // reset the reset flag to 0 if reset option was selected before
            }
        }
        clcd_putch(' ',LINE2(0));
        clcd_print("  ",LINE2(9));
        clcd_print(events[i], LINE2(11));  
        clcd_putch(' ',LINE2(13));
        clcd_print(speed , LINE2(14));
        
        if(event_count > 10)
        {
            event_count = 10;
        }
}

//function to store the events
void store_events(char* time, char** event, char* speed)
{
    //to store the time info
    for(int i = 0 ; i< 8; i++)
    {
        write_ext_eeprom(addr++, time[i]);
    }
    //to store the gear info
    for(int i = 0 ; i< 2; i++)
    {
        write_ext_eeprom(addr++, event[i]);
    }
    //to store the speed info
    for(int i = 0 ; i< 2; i++)
    {
        write_ext_eeprom(addr++, speed[i]);
    }
         //if 10 events are recorded overwrite the 11th event from 0th position
    if(addr == 120)
    {
        addr = 0x00;
    }
}